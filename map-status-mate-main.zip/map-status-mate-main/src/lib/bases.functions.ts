import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { usuarioAEmail } from "./usuario";

async function asegurarAdmin(supabase: any, userId: string) {
  const { data, error } = await supabase.rpc("has_role", { _user_id: userId, _role: "admin" });
  if (error || !data) throw new Error("Solo el administrador puede hacer esto");
}

export const crearAdminInicial = createServerFn({ method: "POST" })
  .inputValidator((d) =>
    z.object({ email: z.string().email(), password: z.string().min(6) }).parse(d),
  )
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { count } = await supabaseAdmin
      .from("user_roles")
      .select("id", { count: "exact", head: true })
      .eq("role", "admin");
    if ((count ?? 0) > 0) throw new Error("Ya existe un administrador");
    const { data: u, error } = await supabaseAdmin.auth.admin.createUser({
      email: data.email.toLowerCase(),
      password: data.password,
      email_confirm: true,
    });
    if (error || !u.user) throw new Error(error?.message ?? "No se pudo crear");
    await supabaseAdmin.from("user_roles").insert({ user_id: u.user.id, role: "admin" });
    return { ok: true };
  });

export const crearBase = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z
      .object({
        nombre: z.string().trim().min(1).max(100),
        usuario: z.string().trim().min(2).max(60),
        password: z.string().min(6).max(72),
      })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    await asegurarAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: u, error } = await supabaseAdmin.auth.admin.createUser({
      email: usuarioAEmail(data.usuario),
      password: data.password,
      email_confirm: true,
    });
    if (error || !u.user) {
      throw new Error(
        error?.message?.includes("already") ? "Ese usuario ya existe" : (error?.message ?? "Error"),
      );
    }
    const { error: e2 } = await supabaseAdmin.from("bases").insert({
      nombre: data.nombre,
      usuario: data.usuario.toUpperCase(),
      user_id: u.user.id,
    });
    if (e2) {
      await supabaseAdmin.auth.admin.deleteUser(u.user.id);
      throw new Error(e2.message);
    }
    return { ok: true };
  });

export const eliminarBase = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await asegurarAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: b } = await supabaseAdmin.from("bases").select("user_id").eq("id", data.id).single();
    await supabaseAdmin.from("bases").delete().eq("id", data.id);
    if (b?.user_id) await supabaseAdmin.auth.admin.deleteUser(b.user_id);
    return { ok: true };
  });

export const cambiarClaveBase = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z.object({ id: z.string().uuid(), password: z.string().min(6).max(72) }).parse(d),
  )
  .handler(async ({ data, context }) => {
    await asegurarAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: b } = await supabaseAdmin.from("bases").select("user_id").eq("id", data.id).single();
    if (!b?.user_id) throw new Error("Base sin usuario");
    const { error } = await supabaseAdmin.auth.admin.updateUserById(b.user_id, {
      password: data.password,
    });
    if (error) throw new Error(error.message);
    await supabaseAdmin
      .from("bases")
      .update({ session_token: null, session_seen_at: null })
      .eq("id", data.id);
    return { ok: true };
  });
