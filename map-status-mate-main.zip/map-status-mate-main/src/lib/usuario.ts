// Bases log in with a username; auth needs an email, so derive a fixed synthetic one.
export function usuarioAEmail(usuario: string): string {
  const v = usuario.trim();
  if (v.includes("@")) return v.toLowerCase();
  const slug = v
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, ".")
    .replace(/^\.+|\.+$/g, "");
  return `${slug}@bases.gad-app.com`;
}

export const SESSION_TOKEN_KEY = "gad_session_token";
export function sessionToken(): string {
  let t = localStorage.getItem(SESSION_TOKEN_KEY);
  if (!t) {
    t = crypto.randomUUID();
    localStorage.setItem(SESSION_TOKEN_KEY, t);
  }
  return t;
}

export function conectada(seen: string | null): boolean {
  return !!seen && Date.now() - new Date(seen).getTime() < 90_000;
}
