let ctx: AudioContext | null = null;

export function unlockAudio() {
  try {
    ctx ??= new (window.AudioContext || (window as any).webkitAudioContext)();
    void ctx.resume();
  } catch {
    /* ignore */
  }
}

export function playDing() {
  try {
    unlockAudio();
    if (!ctx) return;
    const now = ctx.currentTime;
    [880, 1320, 880].forEach((f, i) => {
      const o = ctx!.createOscillator();
      const g = ctx!.createGain();
      o.type = "sine";
      o.frequency.value = f;
      const t = now + i * 0.18;
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.5, t + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.16);
      o.connect(g).connect(ctx!.destination);
      o.start(t);
      o.stop(t + 0.17);
    });
  } catch {
    /* ignore */
  }
}

export async function pedirPermisoNotificaciones() {
  unlockAudio();
  if ("Notification" in window && Notification.permission === "default") {
    try {
      await Notification.requestPermission();
    } catch {
      /* ignore */
    }
  }
}

export async function registrarSW() {
  if (!("serviceWorker" in navigator)) return;
  const inIframe = window.self !== window.top;
  const isPreview = location.hostname.includes("id-preview--") || location.hostname.includes("lovableproject.com");
  if (inIframe || isPreview) return;
  try {
    await navigator.serviceWorker.register("/sw.js");
  } catch {
    /* ignore */
  }
}

export async function notificar(titulo: string, cuerpo: string) {
  playDing();
  navigator.vibrate?.([250, 120, 250]);
  if (!("Notification" in window) || Notification.permission !== "granted") return;
  if (!document.hidden) return;
  try {
    const reg = await navigator.serviceWorker?.getRegistration();
    if (reg) await reg.showNotification(titulo, { body: cuerpo, icon: "/icon-512.png" });
    else new Notification(titulo, { body: cuerpo, icon: "/icon-512.png" });
  } catch {
    /* ignore */
  }
}
