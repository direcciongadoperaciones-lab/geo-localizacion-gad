import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { usuarioAEmail, sessionToken } from "@/lib/usuario";
import { crearAdminInicial } from "@/lib/bases.functions";
import { pedirPermisoNotificaciones, registrarSW } from "@/lib/notify";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "GEOLOCALIZACIÓN GAD | Ingreso" },
      { name: "description", content: "Ingreso de bases y administrador al sistema de geolocalización GAD." },
      { property: "og:title", content: "GEOLOCALIZACIÓN GAD" },
      { property: "og:description", content: "Bases GAD: estado, ubicación y mensajes en tiempo real." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Login,
});

const inputCls =
  "h-11 w-full rounded-md border border-input bg-secondary/60 px-3 text-sm outline-none placeholder:text-muted-foreground focus:ring-1 focus:ring-ring";

export async function destinoSegunRol(userId: string): Promise<"/admin" | "/base"> {
  const { data } = await supabase.from("user_roles").select("role").eq("user_id", userId);
  return data?.some((r) => r.role === "admin") ? "/admin" : "/base";
}

function Login() {
  const navigate = useNavigate();
  const crearAdmin = useServerFn(crearAdminInicial);
  const [usuario, setUsuario] = useState("");
  const [clave, setClave] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [cargando, setCargando] = useState(false);
  const [hayAdmin, setHayAdmin] = useState<boolean | null>(null);

  useEffect(() => {
    void registrarSW();
    supabase.rpc("hay_admin").then(({ data }) => setHayAdmin(!!data));
    supabase.auth.getUser().then(async ({ data }) => {
      if (data.user) navigate({ to: await destinoSegunRol(data.user.id), replace: true });
    });
  }, [navigate]);

  async function ingresar(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setCargando(true);
    await pedirPermisoNotificaciones();
    try {
      if (hayAdmin === false) {
        await crearAdmin({ data: { email: usuario.trim(), password: clave } });
      }
      const { data, error } = await supabase.auth.signInWithPassword({
        email: usuarioAEmail(usuario),
        password: clave,
      });
      if (error || !data.user) throw new Error("Usuario o contraseña incorrectos");
      const destino = await destinoSegunRol(data.user.id);
      if (destino === "/base") {
        const { data: ok } = await supabase.rpc("reclamar_sesion", { _token: sessionToken() });
        if (!ok) {
          await supabase.auth.signOut();
          throw new Error("Otra persona ya está activa con esta base. Esperá a que cierre sesión.");
        }
      }
      navigate({ to: destino, replace: true });
    } catch (err: any) {
      setError(err?.message ?? "Error al ingresar");
    } finally {
      setCargando(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center px-4">
      <form onSubmit={ingresar} className="w-full max-w-sm space-y-3 rounded-lg border bg-card p-6 shadow-xl">
        <img src="/icon-192.png" alt="GAD" width={56} height={56} className="rounded-md" />
        <h1 className="text-3xl font-bold uppercase">Geolocalización GAD</h1>
        <p className="text-sm text-muted-foreground">
          {hayAdmin === false
            ? "Primera vez: creá la cuenta del administrador con tu correo y una contraseña."
            : "Ingresá con el usuario y la clave que te dio el administrador"}
        </p>
        <input
          className={inputCls}
          placeholder={hayAdmin === false ? "Correo del administrador" : "Usuario (ej: GAD ESCOBAR)"}
          value={usuario}
          onChange={(e) => setUsuario(e.target.value)}
          autoCapitalize="characters"
          required
        />
        <input
          className={inputCls}
          type="password"
          placeholder="Contraseña"
          value={clave}
          onChange={(e) => setClave(e.target.value)}
          required
          minLength={6}
        />
        {error && <p className="text-sm text-destructive">{error}</p>}
        <Button type="submit" disabled={cargando} className="h-11 w-full text-base font-semibold">
          {cargando ? "Ingresando…" : hayAdmin === false ? "Crear administrador" : "Ingresar"}
        </Button>
      </form>
    </div>
  );
}
