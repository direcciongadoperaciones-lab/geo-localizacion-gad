import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { LogOut, MapPin, MessageSquare, ClipboardList } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Chat, type Mensaje } from "@/components/Chat";
import { MapaCliente } from "@/components/MapaCliente";
import { sessionToken } from "@/lib/usuario";
import { notificar, pedirPermisoNotificaciones, registrarSW, unlockAudio } from "@/lib/notify";
import type { Database } from "@/integrations/supabase/types";

type Base = Database["public"]["Tables"]["bases"]["Row"];

export const Route = createFileRoute("/_authenticated/base")({
  head: () => ({
    meta: [
      { title: "Mi base | GEOLOCALIZACIÓN GAD" },
      { name: "description", content: "Formulario, ubicación y mensajes de la base." },
      { property: "og:title", content: "Mi base | GEOLOCALIZACIÓN GAD" },
      { property: "og:description", content: "Formulario, ubicación y mensajes de la base." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: PaginaBase,
});

const inputCls =
  "w-full rounded-md border border-input bg-secondary/60 px-3 py-2 text-sm outline-none placeholder:text-muted-foreground focus:ring-1 focus:ring-ring";

function PaginaBase() {
  const navigate = useNavigate();
  const { user } = Route.useRouteContext();
  const [base, setBase] = useState<Base | null>(null);
  const [mensajes, setMensajes] = useState<Mensaje[]>([]);
  const [tab, setTab] = useState<"form" | "msg" | "mapa">("form");
  const [form, setForm] = useState({ responsable: "", telefono: "", direccion: "", moviles: "", observaciones: "" });
  const [gpsError, setGpsError] = useState<string | null>(null);
  const tabRef = useRef(tab);
  tabRef.current = tab;
  const [noLeidos, setNoLeidos] = useState(0);

  const salir = useCallback(
    async (motivo?: string) => {
      await supabase.rpc("liberar_sesion", { _token: sessionToken() });
      await supabase.auth.signOut();
      if (motivo) toast.error(motivo);
      navigate({ to: "/", replace: true });
    },
    [navigate],
  );

  // Load base + messages
  useEffect(() => {
    void registrarSW();
    void pedirPermisoNotificaciones();
    (async () => {
      const { data: b } = await supabase.from("bases").select("*").eq("user_id", user.id).maybeSingle();
      if (!b) {
        navigate({ to: "/admin", replace: true });
        return;
      }
      setBase(b);
      setForm({
        responsable: b.responsable ?? "",
        telefono: b.telefono ?? "",
        direccion: b.direccion ?? "",
        moviles: b.moviles ?? "",
        observaciones: b.observaciones ?? "",
      });
      const { data: m } = await supabase.from("mensajes").select("*").eq("base_id", b.id).order("created_at");
      setMensajes(m ?? []);
      setNoLeidos((m ?? []).filter((x) => x.de === "admin" && !x.leido).length);
    })();
  }, [user.id, navigate]);

  // Single active session heartbeat
  useEffect(() => {
    if (!base) return;
    const tick = async () => {
      const { data } = await supabase.rpc("reclamar_sesion", { _token: sessionToken() });
      if (data === false) salir("Otra persona tomó la sesión de esta base.");
    };
    void tick();
    const i = setInterval(tick, 30_000);
    return () => clearInterval(i);
  }, [base?.id, salir]);

  // Realtime
  useEffect(() => {
    if (!base) return;
    const ch = supabase
      .channel(`base-${base.id}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "mensajes", filter: `base_id=eq.${base.id}` }, (p) => {
        const m = p.new as Mensaje;
        setMensajes((prev) => (prev.some((x) => x.id === m.id) ? prev : [...prev, m]));
        if (m.de === "admin") {
          void notificar("Mensaje del administrador", m.texto);
          toast.info(`Administrador: ${m.texto}`);
          if (tabRef.current !== "msg") setNoLeidos((n) => n + 1);
        }
      })
      .on("postgres_changes", { event: "DELETE", schema: "public", table: "mensajes" }, (p) => {
        setMensajes((prev) => prev.filter((x) => x.id !== (p.old as any).id));
      })
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "bases", filter: `id=eq.${base.id}` }, (p) => {
        setBase(p.new as Base);
      })
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [base?.id]);

  // Mark admin messages read when viewing chat
  useEffect(() => {
    if (tab !== "msg" || !base) return;
    setNoLeidos(0);
    void supabase.from("mensajes").update({ leido: true }).eq("base_id", base.id).eq("de", "admin").eq("leido", false);
  }, [tab, base?.id, mensajes.length]);

  // GPS
  useEffect(() => {
    if (!base) return undefined;
    if (!("geolocation" in navigator)) {
      setGpsError("Este dispositivo no tiene GPS disponible");
      return undefined;
    }
    let last = 0;
    const id = navigator.geolocation.watchPosition(
      (pos) => {
        setGpsError(null);
        const now = Date.now();
        if (now - last < 15_000) return;
        last = now;
        void supabase.rpc("actualizar_ubicacion", { _lat: pos.coords.latitude, _lng: pos.coords.longitude });
      },
      (err) => setGpsError(err.code === 1 ? "Activá el permiso de ubicación para esta app" : "No se pudo obtener la ubicación"),
      { enableHighAccuracy: true, maximumAge: 10_000, timeout: 30_000 },
    );
    return () => navigator.geolocation.clearWatch(id);
  }, [base?.id]);

  if (!base) return <div className="flex min-h-screen items-center justify-center text-muted-foreground">Cargando…</div>;

  const ocupada = base.estado === "ocupada";

  async function cambiarEstado() {
    unlockAudio();
    const nuevo = ocupada ? "disponible" : "ocupada";
    const { error } = await supabase.rpc("cambiar_estado", { _estado: nuevo });
    if (error) { toast.error(error.message); return; }
    setBase((b) => (b ? { ...b, estado: nuevo } : b));
    toast.success(nuevo === "disponible" ? "Servicio finalizado: base DISPONIBLE" : "Servicio iniciado: base OCUPADA");
  }

  async function guardar(e: React.FormEvent) {
    e.preventDefault();
    const { error } = await supabase.rpc("guardar_formulario", {
      _responsable: form.responsable,
      _telefono: form.telefono,
      _direccion: form.direccion,
      _moviles: form.moviles,
      _observaciones: form.observaciones,
    });
    if (error) toast.error(error.message);
    else toast.success("Formulario guardado");
  }

  async function enviar(texto: string) {
    const { error } = await supabase.from("mensajes").insert({ base_id: base!.id, de: "base", texto });
    if (error) toast.error(error.message);
  }

  const tabs = [
    { id: "form" as const, label: "Formulario", icon: ClipboardList },
    { id: "msg" as const, label: "Mensajes", icon: MessageSquare, badge: noLeidos },
    { id: "mapa" as const, label: "Ubicación", icon: MapPin },
  ];

  return (
    <div className="flex h-[100dvh] flex-col" onClick={unlockAudio}>
      <header className="flex items-center justify-between gap-2 border-b bg-card px-4 py-3">
        <div className="min-w-0">
          <h1 className="truncate text-2xl font-bold uppercase">{base.nombre}</h1>
          <span className={`inline-block rounded px-2 py-0.5 text-xs font-bold ${ocupada ? "bg-ocupada text-ocupada-foreground" : "bg-libre text-libre-foreground"}`}>
            {ocupada ? "OCUPADA" : "DISPONIBLE"}
          </span>
        </div>
        <Button variant="ghost" size="sm" onClick={() => salir()}>
          <LogOut /> Salir
        </Button>
      </header>

      <div className="border-b bg-card px-4 py-3">
        <Button
          onClick={cambiarEstado}
          className={`h-12 w-full text-base font-bold ${ocupada ? "bg-libre text-libre-foreground hover:bg-libre/90" : "bg-ocupada text-ocupada-foreground hover:bg-ocupada/90"}`}
        >
          {ocupada ? "FINALIZAR SERVICIO (pasar a disponible)" : "INICIAR SERVICIO (pasar a ocupada)"}
        </Button>
        {gpsError && <p className="mt-2 text-xs text-destructive">{gpsError}</p>}
      </div>

      <main className="min-h-0 flex-1">
        {tab === "form" && (
          <form onSubmit={guardar} className="mx-auto max-w-lg space-y-3 overflow-y-auto p-4">
            {([
              ["responsable", "Responsable a cargo"],
              ["telefono", "Teléfono de contacto"],
              ["direccion", "Dirección / lugar"],
              ["moviles", "Móviles / personal"],
            ] as const).map(([k, label]) => (
              <label key={k} className="block space-y-1">
                <span className="text-sm text-muted-foreground">{label}</span>
                <input className={inputCls} value={form[k]} onChange={(e) => setForm({ ...form, [k]: e.target.value })} maxLength={200} />
              </label>
            ))}
            <label className="block space-y-1">
              <span className="text-sm text-muted-foreground">Observaciones</span>
              <textarea className={`${inputCls} min-h-24`} value={form.observaciones} onChange={(e) => setForm({ ...form, observaciones: e.target.value })} maxLength={2000} />
            </label>
            <Button type="submit" className="h-11 w-full font-semibold">Guardar formulario</Button>
            {base.formulario_at && (
              <p className="text-center text-xs text-muted-foreground">
                Último guardado: {new Date(base.formulario_at).toLocaleString("es-AR")}
              </p>
            )}
          </form>
        )}
        {tab === "msg" && <Chat mensajes={mensajes} yo="base" onEnviar={enviar} onBorrar={async (id) => { const { error } = await supabase.from("mensajes").delete().eq("id", id); if (error) toast.error(error.message); else setMensajes((p) => p.filter((m) => m.id !== id)); }} />}
        {tab === "mapa" && (
          <div className="flex h-full flex-col">
            <div className="min-h-0 flex-1">
              {base.lat != null && base.lng != null ? (
                <MapaCliente puntos={[{ id: base.id, nombre: base.nombre, lat: base.lat, lng: base.lng, estado: base.estado }]} />
              ) : (
                <div className="flex h-full items-center justify-center p-6 text-center text-muted-foreground">
                  Esperando la ubicación del GPS…
                </div>
              )}
            </div>
            {base.ubicacion_at && (
              <p className="border-t px-4 py-2 text-xs text-muted-foreground">
                Ubicación enviada: {new Date(base.ubicacion_at).toLocaleTimeString("es-AR")}
              </p>
            )}
          </div>
        )}
      </main>

      <nav className="grid grid-cols-3 border-t bg-card pb-[env(safe-area-inset-bottom)]">
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`relative flex flex-col items-center gap-1 py-2 text-xs ${tab === t.id ? "text-primary" : "text-muted-foreground"}`}
          >
            <t.icon className="size-5" />
            {t.label}
            {!!t.badge && (
              <span className="absolute right-1/4 top-1 rounded-full bg-ocupada px-1.5 text-[10px] font-bold text-ocupada-foreground">{t.badge}</span>
            )}
          </button>
        ))}
      </nav>
    </div>
  );
}
