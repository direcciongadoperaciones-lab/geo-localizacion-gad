import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { LogOut, Plus } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Chat, type Mensaje } from "@/components/Chat";
import { MapaCliente } from "@/components/MapaCliente";
import { crearBase, eliminarBase } from "@/lib/bases.functions";
import { conectada } from "@/lib/usuario";
import { notificar, pedirPermisoNotificaciones, unlockAudio } from "@/lib/notify";
import type { Database } from "@/integrations/supabase/types";

type Base = Database["public"]["Tables"]["bases"]["Row"];

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    meta: [
      { title: "Administrador | GEOLOCALIZACIÓN GAD" },
      { name: "description", content: "Mapa y estado de todas las bases GAD." },
      { property: "og:title", content: "Administrador | GEOLOCALIZACIÓN GAD" },
      { property: "og:description", content: "Mapa y estado de todas las bases GAD." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Admin,
});

const inputCls = "h-10 w-full rounded-md border border-input bg-secondary/60 px-3 text-sm outline-none";

function Admin() {
  const navigate = useNavigate();
  const crear = useServerFn(crearBase);
  const eliminar = useServerFn(eliminarBase);
  const [bases, setBases] = useState<Base[]>([]);
  const [sel, setSel] = useState<string | null>(null);
  const [mensajes, setMensajes] = useState<Mensaje[]>([]);
  const [nueva, setNueva] = useState<{ nombre: string; usuario: string; password: string } | null>(null);
  const selRef = useRef(sel);
  selRef.current = sel;

  async function cargar() {
    const { data } = await supabase.from("bases").select("*").order("nombre");
    setBases(data ?? []);
  }

  useEffect(() => {
    void pedirPermisoNotificaciones();
    void cargar();
    const ch = supabase
      .channel("admin")
      .on("postgres_changes", { event: "*", schema: "public", table: "bases" }, () => void cargar())
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "mensajes" }, (p) => {
        const m = p.new as Mensaje & { base_id: string };
        if (m.base_id === selRef.current) setMensajes((prev) => (prev.some((x) => x.id === m.id) ? prev : [...prev, m]));
        if (m.de === "base") {
          void notificar("Respuesta de una base", m.texto);
          toast.info(`Base respondió: ${m.texto}`);
        }
      })
      .subscribe();
    const i = setInterval(() => void cargar(), 60_000);
    return () => {
      supabase.removeChannel(ch);
      clearInterval(i);
    };
  }, []);

  useEffect(() => {
    if (!sel) return;
    supabase.from("mensajes").select("*").eq("base_id", sel).order("created_at").then(({ data }) => setMensajes(data ?? []));
  }, [sel]);

  const base = bases.find((b) => b.id === sel);
  const libres = bases.filter((b) => b.estado !== "ocupada").length;
  const ocupadas = bases.length - libres;
  const puntos = bases
    .filter((b) => b.lat != null && b.lng != null)
    .map((b) => ({ id: b.id, nombre: b.nombre, lat: b.lat!, lng: b.lng!, estado: b.estado, detalle: b.responsable ?? undefined }));

  async function salir() {
    await supabase.auth.signOut();
    navigate({ to: "/", replace: true });
  }

  async function limpiar(id: string) {
    if (!confirm("¿Borrar formulario, ubicación y mensajes de esta base?")) return;
    await supabase.from("mensajes").delete().eq("base_id", id);
    await supabase.from("bases").update({ responsable: null, telefono: null, direccion: null, moviles: null, observaciones: null, formulario_at: null, lat: null, lng: null, ubicacion_at: null, estado: "disponible" }).eq("id", id);
    setMensajes([]);
    toast.success("Registro eliminado");
  }

  return (
    <div className="flex h-[100dvh] flex-col md:flex-row" onClick={unlockAudio}>
      <aside className="flex max-h-[40dvh] flex-col border-b bg-sidebar md:max-h-none md:w-80 md:border-b-0 md:border-r">
        <div className="flex items-center justify-between p-3">
          <h1 className="text-2xl font-bold uppercase">GAD Bases</h1>
          <Button variant="ghost" size="sm" onClick={salir}><LogOut /></Button>
        </div>
        <div className="grid grid-cols-2 gap-2 px-3 pb-3 text-center text-sm font-bold">
          <div className="rounded bg-libre py-1 text-libre-foreground">Disponibles {libres}</div>
          <div className="rounded bg-ocupada py-1 text-ocupada-foreground">Ocupadas {ocupadas}</div>
        </div>
        <div className="px-3 pb-2">
          <Button size="sm" className="w-full" onClick={() => setNueva({ nombre: "", usuario: "", password: "" })}><Plus /> Nueva base</Button>
        </div>
        <ul className="flex-1 overflow-y-auto">
          {bases.map((b) => (
            <li key={b.id}>
              <button onClick={() => setSel(b.id)} className={`flex w-full items-center gap-2 px-3 py-2 text-left text-sm hover:bg-sidebar-accent ${sel === b.id ? "bg-sidebar-accent" : ""}`}>
                <span className={`size-3 rounded-full ${b.estado === "ocupada" ? "bg-ocupada" : "bg-libre"}`} />
                <span className="flex-1 truncate">{b.nombre}</span>
                {conectada(b.session_seen_at) && <span className="text-[10px] text-libre">en línea</span>}
                {b.lat == null && <span className="text-[10px] text-muted-foreground">sin GPS</span>}
              </button>
            </li>
          ))}
        </ul>
      </aside>

      <main className="relative min-h-0 flex-1">
        <MapaCliente puntos={puntos} seleccionado={sel} onSelect={setSel} />
      </main>

      {base && (
        <section className="flex max-h-[50dvh] flex-col border-t bg-card md:max-h-none md:w-96 md:border-l md:border-t-0">
          <div className="space-y-1 border-b p-3 text-sm">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold uppercase">{base.nombre}</h2>
              <button className="text-muted-foreground" onClick={() => setSel(null)}>✕</button>
            </div>
            <p className="text-xs text-muted-foreground">Usuario: {base.usuario} · {base.estado === "ocupada" ? "OCUPADA" : "DISPONIBLE"}</p>
            {base.responsable && <p>Responsable: {base.responsable}</p>}
            {base.telefono && <p>Tel: {base.telefono}</p>}
            {base.direccion && <p>Dirección: {base.direccion}</p>}
            {base.moviles && <p>Móviles: {base.moviles}</p>}
            {base.observaciones && <p>Obs: {base.observaciones}</p>}
            <div className="flex flex-wrap gap-2 pt-2">
              <Button size="sm" variant="outline" onClick={() => limpiar(base.id)}>Eliminar registro</Button>
              <Button size="sm" variant="outline" onClick={async () => { await supabase.from("bases").update({ session_token: null, session_seen_at: null }).eq("id", base.id); toast.success("Sesión liberada"); }}>Liberar sesión</Button>
              <Button size="sm" variant="destructive" onClick={async () => { if (!confirm("¿Eliminar la base y su usuario?")) return; await eliminar({ data: { id: base.id } }); setSel(null); void cargar(); }}>Eliminar base</Button>
            </div>
          </div>
          <div className="min-h-0 flex-1">
            <Chat
              mensajes={mensajes}
              yo="admin"
              onEnviar={async (texto) => { const { error } = await supabase.from("mensajes").insert({ base_id: base.id, de: "admin", texto }); if (error) toast.error(error.message); }}
              onBorrar={async (id) => { const { error } = await supabase.from("mensajes").delete().eq("id", id); if (error) toast.error(error.message); else setMensajes((p) => p.filter((m) => m.id !== id)); }}
              onBorrarTodo={async () => { const { error } = await supabase.from("mensajes").delete().eq("base_id", base.id); if (error) toast.error(error.message); else setMensajes([]); }}
            />
          </div>
        </section>
      )}

      {nueva && (
        <div className="fixed inset-0 z-[1000] flex items-center justify-center bg-background/80 p-4">
          <form
            className="w-full max-w-sm space-y-3 rounded-lg border bg-card p-5"
            onSubmit={async (e) => {
              e.preventDefault();
              try {
                await crear({ data: nueva });
                toast.success("Base creada");
                setNueva(null);
                void cargar();
              } catch (err: any) {
                toast.error(err?.message ?? "Error");
              }
            }}
          >
            <h2 className="text-xl font-bold uppercase">Nueva base</h2>
            <input className={inputCls} placeholder="Nombre (ej: Base Escobar)" value={nueva.nombre} onChange={(e) => setNueva({ ...nueva, nombre: e.target.value })} required />
            <input className={inputCls} placeholder="Usuario (ej: GAD ESCOBAR)" value={nueva.usuario} onChange={(e) => setNueva({ ...nueva, usuario: e.target.value })} required />
            <input className={inputCls} placeholder="Contraseña (mín. 6)" value={nueva.password} onChange={(e) => setNueva({ ...nueva, password: e.target.value })} minLength={6} required />
            <div className="flex gap-2">
              <Button type="button" variant="outline" className="flex-1" onClick={() => setNueva(null)}>Cancelar</Button>
              <Button type="submit" className="flex-1">Crear</Button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
