import { lazy, Suspense, useEffect, useState } from "react";
import type { PuntoMapa } from "./Mapa";

const Mapa = lazy(() => import("./Mapa"));

export function MapaCliente(props: {
  puntos: PuntoMapa[];
  seleccionado?: string | null;
  onSelect?: (id: string) => void;
}) {
  const [ok, setOk] = useState(false);
  useEffect(() => setOk(true), []);
  const fallback = <div className="flex h-full items-center justify-center text-muted-foreground">Cargando mapa…</div>;
  if (!ok) return fallback;
  return (
    <Suspense fallback={fallback}>
      <Mapa {...props} />
    </Suspense>
  );
}
export type { PuntoMapa };
