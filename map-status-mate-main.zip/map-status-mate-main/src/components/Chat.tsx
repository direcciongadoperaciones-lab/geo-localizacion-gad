import { useEffect, useRef, useState } from "react";
import { Send, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";

export type Mensaje = { id: string; de: string; texto: string; created_at: string; leido: boolean };

export function Chat({
  mensajes,
  yo,
  onEnviar,
  onBorrar,
  onBorrarTodo,
}: {
  mensajes: Mensaje[];
  yo: "admin" | "base";
  onEnviar: (t: string) => Promise<void>;
  onBorrar?: ((id: string) => Promise<void>) | undefined;
  onBorrarTodo?: (() => Promise<void>) | undefined;
}) {
  const [texto, setTexto] = useState("");
  const [enviando, setEnviando] = useState(false);
  const fin = useRef<HTMLDivElement>(null);
  useEffect(() => fin.current?.scrollIntoView({ behavior: "smooth" }), [mensajes.length]);

  async function enviar(e: React.FormEvent) {
    e.preventDefault();
    const t = texto.trim();
    if (!t) return;
    setEnviando(true);
    try {
      await onEnviar(t);
      setTexto("");
    } finally {
      setEnviando(false);
    }
  }

  return (
    <div className="flex h-full min-h-0 flex-col">
      {onBorrarTodo && mensajes.length > 0 && (
        <div className="flex justify-end border-b px-3 py-1">
          <button
            className="flex items-center gap-1 text-xs text-destructive"
            onClick={() => { if (confirm("¿Borrar todos los mensajes?")) void onBorrarTodo(); }}
          >
            <Trash2 className="size-3" /> Borrar todos
          </button>
        </div>
      )}
      <div className="flex-1 space-y-2 overflow-y-auto p-3">
        {mensajes.length === 0 && (
          <p className="py-8 text-center text-sm text-muted-foreground">Sin mensajes todavía</p>
        )}
        {mensajes.map((m) => {
          const mio = m.de === yo;
          return (
            <div key={m.id} className={`flex ${mio ? "justify-end" : "justify-start"}`}>
              <div
                className={`max-w-[80%] rounded-lg px-3 py-2 text-sm ${mio ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground"}`}
              >
                <div className="whitespace-pre-wrap break-words">{m.texto}</div>
                <div className="mt-1 flex items-center gap-2 text-[10px] opacity-70">
                  <span>
                    {m.de === "admin" ? "Administrador" : "Base"} ·{" "}
                    {new Date(m.created_at).toLocaleString("es-AR", { hour: "2-digit", minute: "2-digit", day: "2-digit", month: "2-digit" })}
                  </span>
                  {onBorrar && (
                    <button aria-label="Borrar mensaje" onClick={() => void onBorrar(m.id)}>
                      <Trash2 className="size-3" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
        <div ref={fin} />
      </div>
      <form onSubmit={enviar} className="flex gap-2 border-t p-2">
        <input
          value={texto}
          onChange={(e) => setTexto(e.target.value)}
          placeholder="Escribí un mensaje…"
          maxLength={1000}
          className="h-10 flex-1 rounded-md border border-input bg-background px-3 text-sm outline-none focus:ring-1 focus:ring-ring"
        />
        <Button type="submit" disabled={enviando || !texto.trim()} className="h-10">
          <Send /> Enviar
        </Button>
      </form>
    </div>
  );
}
