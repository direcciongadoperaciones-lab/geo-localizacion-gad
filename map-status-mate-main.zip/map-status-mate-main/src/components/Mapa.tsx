import { useEffect, useRef } from "react";
import L from "leaflet";

export type PuntoMapa = {
  id: string;
  nombre: string;
  lat: number;
  lng: number;
  estado: string;
  detalle?: string | undefined;
};

const COLOR = { disponible: "#22c55e", ocupada: "#ef4444" } as const;

export default function Mapa({
  puntos,
  seleccionado,
  onSelect,
}: {
  puntos: PuntoMapa[];
  seleccionado?: string | null;
  onSelect?: (id: string) => void;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const map = useRef<L.Map | null>(null);
  const layer = useRef<L.LayerGroup | null>(null);
  const markers = useRef<Record<string, L.CircleMarker>>({});
  const fitted = useRef(false);

  useEffect(() => {
    if (!ref.current || map.current) return;
    map.current = L.map(ref.current, { zoomControl: true }).setView([-34.6, -58.45], 10);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: "© OpenStreetMap",
      maxZoom: 19,
    }).addTo(map.current);
    layer.current = L.layerGroup().addTo(map.current);
    return () => {
      map.current?.remove();
      map.current = null;
    };
  }, []);

  useEffect(() => {
    if (!layer.current || !map.current) return;
    layer.current.clearLayers();
    markers.current = {};
    for (const p of puntos) {
      const color = COLOR[p.estado as keyof typeof COLOR] ?? COLOR.disponible;
      const sel = p.id === seleccionado;
      const m = L.circleMarker([p.lat, p.lng], {
        radius: sel ? 14 : 10,
        color: sel ? "#f59e0b" : "#ffffff",
        weight: sel ? 4 : 2,
        fillColor: color,
        fillOpacity: 0.95,
      })
        .bindTooltip(p.nombre, { permanent: sel, direction: "top", offset: [0, -10] })
        .bindPopup(
          `<b>${escapeHtml(p.nombre)}</b><br/>${p.estado === "ocupada" ? "OCUPADA" : "DISPONIBLE"}${p.detalle ? "<br/>" + escapeHtml(p.detalle) : ""}`,
        );
      m.on("click", () => onSelect?.(p.id));
      m.addTo(layer.current);
      markers.current[p.id] = m;
    }
    if (!fitted.current && puntos.length) {
      fitted.current = true;
      if (puntos.length === 1) map.current.setView([puntos[0]!.lat, puntos[0]!.lng], 15);
      else map.current.fitBounds(L.latLngBounds(puntos.map((p) => [p.lat, p.lng])), { padding: [40, 40] });
    }
  }, [puntos, seleccionado, onSelect]);

  useEffect(() => {
    if (!seleccionado || !map.current) return;
    const m = markers.current[seleccionado];
    if (m) {
      map.current.flyTo(m.getLatLng(), 16, { duration: 0.8 });
      m.openPopup();
    }
  }, [seleccionado]);

  return <div ref={ref} className="h-full w-full" />;
}

function escapeHtml(s: string) {
  return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]!);
}
