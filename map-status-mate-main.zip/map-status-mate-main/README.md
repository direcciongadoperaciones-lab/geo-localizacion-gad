# Map Manager Pro

https://personalized-geo-map.lovable.app/ A ESTO QUIERO QUE LAS BASES QUE YO LES ASIGNE EL USUARIO Y CONTRASEÑA ELLOS SOLAMENTE VEAN EL FORMULARIO QUE LLENARON Y QUE TENGAN PARA RESPONDE LOS MENSAJES QUE LE MANDO Y QUE TENGAN LA UBICACION Y YO COMO ADMINISTRADOR SOLAMENTE VEA DONDE ESTAN Y QUE SI TOCO UNA BASE ME MARQUE EN EL MAPA DONDE ESTAN. Y LAS BASES ELLOS PUEDAN FINALIZAR CUANDO SE TERMINE EL SERVICIO LA UBICACION Y YA PASEN A COLOR VERDE SI ESTAN DESOCUPADOS Y SI ESTAN OCUPADOS QUE FIGURE EN ROJO Y QUE ESO SE REFLEJE EN BASES DISPONIBLES O OCUPADAS COMO ESTA EN EL PROYECTO. CUANDO LO TENGAS DAME EL LINK Y DAME LA FORMA PARA QUE SE PUEDA DESCARGA LA APLICACION EN CELULARES PARA QUE LOS USURIOS INGRESEN POR AHI Y QUE CUANDO LES ENVIO UNA NOTIFICACION LE SUENE COMO MENSAJES TAMBIEN ME SUENE A MI CUANDO ELLOS CONTESTEN.- NECESITO TODO ESOE QUE HAGAS DE UNA VEZ Ý TAMBIEN QUIERO QUE PUEDA ELIMINAR REGISTRO DE UNA BASE Y QUE LOS USURIOS PUEDAN INGRESAR VARIAS PERSONAS CON LA CLAVE QUE YO LE DI PERO SOLAMENTE UNA SOLA PERSONA CUANDO ESTE ACTIVA

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://map-status-mate.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/7263c46e-a0c3-48ed-83e5-5d52c13de576).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
