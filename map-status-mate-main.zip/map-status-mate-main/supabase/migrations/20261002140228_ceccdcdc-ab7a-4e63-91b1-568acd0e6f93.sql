revoke execute on function public.has_role(uuid, app_role) from public, anon;
revoke execute on function public.reclamar_sesion(text), public.liberar_sesion(text),
  public.guardar_formulario(text,text,text,text,text), public.actualizar_ubicacion(double precision,double precision),
  public.cambiar_estado(text) from public, anon;