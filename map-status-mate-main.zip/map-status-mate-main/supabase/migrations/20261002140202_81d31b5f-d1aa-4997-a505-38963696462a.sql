create type public.app_role as enum ('admin', 'user');

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  role app_role not null,
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;

create or replace function public.has_role(_user_id uuid, _role app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

create policy "own roles" on public.user_roles for select to authenticated
using (user_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

create table public.bases (
  id uuid primary key default gen_random_uuid(),
  nombre text not null,
  usuario text not null unique,
  user_id uuid unique,
  estado text not null default 'disponible',
  lat double precision,
  lng double precision,
  ubicacion_at timestamptz,
  responsable text,
  telefono text,
  direccion text,
  moviles text,
  observaciones text,
  formulario_at timestamptz,
  session_token text,
  session_seen_at timestamptz,
  created_at timestamptz not null default now()
);
grant select, insert, update, delete on public.bases to authenticated;
grant all on public.bases to service_role;
alter table public.bases enable row level security;
create policy "admin all bases" on public.bases for all to authenticated
using (public.has_role(auth.uid(), 'admin')) with check (public.has_role(auth.uid(), 'admin'));
create policy "base reads own" on public.bases for select to authenticated
using (user_id = auth.uid());

create table public.mensajes (
  id uuid primary key default gen_random_uuid(),
  base_id uuid not null references public.bases(id) on delete cascade,
  de text not null,
  texto text not null,
  leido boolean not null default false,
  created_at timestamptz not null default now()
);
grant select, insert, update, delete on public.mensajes to authenticated;
grant all on public.mensajes to service_role;
alter table public.mensajes enable row level security;
create policy "admin all mensajes" on public.mensajes for all to authenticated
using (public.has_role(auth.uid(), 'admin')) with check (public.has_role(auth.uid(), 'admin'));
create policy "base reads own mensajes" on public.mensajes for select to authenticated
using (exists (select 1 from public.bases b where b.id = base_id and b.user_id = auth.uid()));
create policy "base sends mensajes" on public.mensajes for insert to authenticated
with check (de = 'base' and exists (select 1 from public.bases b where b.id = base_id and b.user_id = auth.uid()));
create policy "base marks read" on public.mensajes for update to authenticated
using (exists (select 1 from public.bases b where b.id = base_id and b.user_id = auth.uid()))
with check (exists (select 1 from public.bases b where b.id = base_id and b.user_id = auth.uid()));

create index on public.mensajes (base_id, created_at);

-- RPCs for base users
create or replace function public.hay_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where role = 'admin')
$$;
grant execute on function public.hay_admin() to anon, authenticated;

create or replace function public.reclamar_sesion(_token text) returns boolean
language plpgsql security definer set search_path = public as $$
declare b public.bases;
begin
  select * into b from public.bases where user_id = auth.uid() for update;
  if not found then return false; end if;
  if b.session_token is null or b.session_token = _token
     or b.session_seen_at is null or b.session_seen_at < now() - interval '90 seconds' then
    update public.bases set session_token = _token, session_seen_at = now() where id = b.id;
    return true;
  end if;
  return false;
end $$;

create or replace function public.liberar_sesion(_token text) returns void
language sql security definer set search_path = public as $$
  update public.bases set session_token = null, session_seen_at = null
  where user_id = auth.uid() and session_token = _token
$$;

create or replace function public.guardar_formulario(_responsable text, _telefono text, _direccion text, _moviles text, _observaciones text)
returns void language sql security definer set search_path = public as $$
  update public.bases set responsable = _responsable, telefono = _telefono, direccion = _direccion,
    moviles = _moviles, observaciones = _observaciones, formulario_at = now()
  where user_id = auth.uid()
$$;

create or replace function public.actualizar_ubicacion(_lat double precision, _lng double precision)
returns void language sql security definer set search_path = public as $$
  update public.bases set lat = _lat, lng = _lng, ubicacion_at = now() where user_id = auth.uid()
$$;

create or replace function public.cambiar_estado(_estado text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if _estado not in ('disponible','ocupada') then raise exception 'estado invalido'; end if;
  update public.bases set estado = _estado where user_id = auth.uid();
end $$;

grant execute on function public.reclamar_sesion(text), public.liberar_sesion(text),
  public.guardar_formulario(text,text,text,text,text), public.actualizar_ubicacion(double precision,double precision),
  public.cambiar_estado(text) to authenticated;

alter publication supabase_realtime add table public.bases;
alter publication supabase_realtime add table public.mensajes;